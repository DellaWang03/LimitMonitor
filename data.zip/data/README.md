# 数据目录结构说明

## 📂 目录结构

```
data/
├── current/                    # 当前最新数据
│   ├── stage0_output/          # 当前配置文件（可手动更新）
│   ├── stage1_output/          # 最新Stage1处理结果
│   └── stage2_output/          # 最新Stage2处理结果
│
├── history/                    # 历史完整快照
│   ├── 2026-01-22/
│   │   ├── stage0_output/      # 该日期使用的配置文件
│   │   ├── stage1_output/      # 该日期的Stage1结果
│   │   └── stage2_output/      # 该日期的Stage2结果
│   ├── 2026-01-21/
│   │   └── ...
│   └── ...
│
└── snapshots/                  # PowerBI截图（用于校验）
    ├── 2026-01-22/
    │   ├── page1.html
    │   ├── page2.html
    │   └── ...
    └── ...
```

## 🔄 工作流程

### 推荐：一键式每日自动化流程

**最简单的方式** - 一个命令完成所有操作：

```bash
# Mac/Linux
bash run_daily.sh

# Windows
run_daily.bat
```

此脚本会自动完成：
1. ✅ 运行 Stage0（处理配置文件）
2. ✅ 运行 Stage1（基础限额计算）
3. ✅ 运行 Stage2（高风险/地域集中度）
4. ✅ 归档完整数据到 history/（包含 Stage0/1/2）

---

### 高级：手动分步执行

如果需要单独运行某个阶段：

```bash
# 步骤1: 运行Stage0（处理配置文件）
python run_stage0.py
# 输出到: data/current/stage0_output/

# 步骤2: 运行Stage1（基础限额计算）
python run_stage1.py
# 输入: data/current/stage0_output/
# 输出到: data/current/stage1_output/

# 步骤3: 运行Stage2（高风险/地域集中度）
python run_stage2.py
# 输入: data/current/stage0_output/ + data/current/stage1_output/
# 输出到: data/current/stage2_output/

# 步骤4: 单独归档（如果需要）
python scripts/daily_archive.py
# 将 data/current/ 完整复制到 data/history/2026-01-22/
```

### 配置文件更新流程

当您需要手动更新配置文件时（例如：调整实控人名单、更新公司净资产）：

**推荐方式**（使用一键脚本）：

```bash
# 1. 更新sample data中的配置文件
#    例如：修改 "sample data/调整实控人名单.xlsx"

# 2. 运行每日脚本（会自动运行Stage0/1/2并归档）
bash run_daily.sh  # Mac/Linux
# 或
run_daily.bat      # Windows
```

**手动方式**（分步执行）：

```bash
# 1. 更新sample data中的配置文件

# 2. 重新运行Stage0生成新的配置输出
python run_stage0.py

# 3. 重新运行Stage1和Stage2
python run_stage1.py
python run_stage2.py

# 4. 归档新的结果（包含更新后的配置）
python scripts/daily_archive.py
```

**重要：** 配置变更会影响所有后续计算结果，归档功能确保您可以追溯任何历史日期使用的配置版本。

---

### 独立归档工具使用场景

`scripts/daily_archive.py` 是一个独立的归档工具，在以下场景下使用：

#### 1. 仅归档（数据已生成，只需备份）

```bash
# 已经运行过 run_stage1.py 和 run_stage2.py
# 但忘记归档了，可以补归档
python scripts/daily_archive.py
```

#### 2. 指定日期归档（手动归档历史数据）

```bash
# 补归档某个历史日期的数据
python scripts/daily_archive.py --date 2026-01-20
```

#### 3. 重新归档（数据有更新，覆盖历史）

```bash
# 发现今天的数据有问题，重新运行了某个Stage
python run_stage2.py                    # 重新生成数据
python scripts/daily_archive.py        # 重新归档（覆盖今天的历史）
```

#### 4. 跨平台使用（不依赖Shell脚本）

```bash
# 在任何平台（Windows/Mac/Linux）都可以使用
python scripts/daily_archive.py
```

## 📊 数据可追溯性

### 完整归档的优势

1. **配置审计**: 可以查看任何历史日期使用的配置文件
2. **结果重现**: 给定历史配置，可以重新计算验证结果
3. **变更追踪**: 对比不同日期的配置差异
4. **合规要求**: 满足金融行业的审计追溯要求

### 查看历史数据

```python
# 在Streamlit中加载历史数据
from src.visualization.data_loader import DataLoader
from datetime import date

# 加载2026-01-22的历史数据
loader = DataLoader(target_date=date(2026, 1, 22))

# 这将加载该日期的完整快照：
# - history/2026-01-22/stage0_output/  (配置文件)
# - history/2026-01-22/stage1_output/  (Stage1结果)
# - history/2026-01-22/stage2_output/  (Stage2结果)
```

## 🗂️ Stage0配置文件说明

Stage0包含以下配置文件（约10个）：

| 文件名 | 说明 | 更新频率 |
|--------|------|----------|
| 调整实控人名单.xlsx | 主体实控人映射关系 | 配置变更时 |
| 调整实控人_北京国有资本.xlsx | 北京国资特殊处理 | 配置变更时 |
| 公司净资产_手工.xlsx | 公司净资产数据 | 季度/年度更新 |
| 公司净资产_手工_每日.xlsx | 每日净资产数据 | 每日 |
| 风控部债券池.xlsx | 债券池配置 | 配置变更时 |
| 风控部债券池_主体.xlsx | 主体池配置 | 配置变更时 |
| ... | ... | ... |

## 🧹 数据清理

已清理的旧文件夹（2026-01-22迁移时）：

- ❌ `data/output/` - 旧的Excel报告（18.02 MB）
- ❌ `data/processed/` - 空文件夹
- ❌ `data/raw/` - 空文件夹
- ❌ `data/stage0_output_test/` - 测试数据（1.39 MB）
- ❌ `data/stage0_output/` - 旧结构，已迁移到`current/`（7.68 MB）
- ❌ `data/stage1_output/` - 旧结构，已迁移到`current/`（6.63 MB）
- ❌ `data/stage2_output/` - 旧结构，已迁移到`current/`（0.74 MB）

**总计释放空间：34.46 MB**

## 📝 注意事项

1. **不要手动删除current/目录**：这是当前运行系统的工作目录
2. **定期清理旧归档**：建议保留最近30-90天的历史数据
3. **配置变更需归档**：每次更新配置文件后，记得运行归档脚本
4. **历史数据只读**：history/目录仅用于查看和审计，不应修改

## 🔧 维护脚本

### 主要脚本

| 脚本 | 功能 | 使用场景 |
|------|------|----------|
| `run_daily.sh` / `run_daily.bat` | 一键式每日运行（处理+归档） | **日常使用**（推荐） |
| `scripts/daily_archive.py` | 独立归档工具 | 补归档、指定日期归档、跨平台 |
| `run_stage0.py` | 单独运行Stage0 | 仅更新配置文件 |
| `run_stage1.py` | 单独运行Stage1 | 调试或单独测试 |
| `run_stage2.py` | 单独运行Stage2 | 调试或单独测试 |

### 历史迁移脚本

- `scripts/migrate_to_full_archive.py` - 一次性迁移脚本（已执行于2026-01-22）

## 📞 联系方式

如有问题，请联系系统管理员。
